import React from 'react';
import PaymentCalc from './components/page/PaymentCalc';

function App() {
  return (
    <div className="App">
      
      <PaymentCalc />
    </div>
  );
}

export default App;
