import { Component } from 'react';

class AffordAssistCalApp extends Component {
    constructor(props) {
        super(props);
        this.state = {
            property_purchase_price: "595000",
            cash_deposit: "10000",
            payment_frequency: "12",
            payment_frequency_monthly: "12",

            property_purchase_price_helpText: false,
            cash_deposit_helpText: false,


            property_value: "595000",
            lvr: "90",
            lvr_helpText: false,
            loan_term: "30",
            repayment_type: "pi",
            interest_rate: "3.25",
            lmi: "2.25",
            lmi_type: "included",



            purchase_type: "first_home_owner",
            first_home_grant: "10000",
            other_grant: "5000",
            other_incentives: "15000",
            interest_free_term: "60",
            is_property_off_the_loan: true,
            property_due_to_omplete: "18",
            minimum_monthly_amount_payable: "1500",

            
        }
        this._isMouted = false;
    }

    
    changeClass = (name,opration=true) =>{
        var error = name+"-helper-text";
        if(opration)
        {
            if(document.getElementById(name).parentNode != undefined)    
            document.getElementById(name).parentNode.classList.add("Mui-error");
            if(document.getElementById(error) != undefined)
            document.getElementById(error).classList.add("Mui-error");
            
        }    
        else
        {    
            if(document.getElementById(name).parentNode != undefined)    
            document.getElementById(name).parentNode.classList.remove("Mui-error");
            if(document.getElementById(error) != undefined)
            document.getElementById(error).classList.remove("Mui-error");
        }    
    }

    setMessage = (event)=>{
        let name = event.target.name+"_helpText";
        let updateState = { ...this.state }
        updateState[name] = true;
        this.setState({
            ...updateState
        });
    }
    removeMessage = (event)=>{
        let name = event.target.name+"_helpText";
        let updateState = { ...this.state }

       // console.log("event",event);
       
        
        updateState[name] = false;
        this.setState({
            ...updateState
        });
    }


    checkMinMaxValidator = (event)=>{
        let name = event.target.name;
        let value = parseFloat(event.target.value);
        let type = event.target.type;
        
        if(name === "property_purchase_price")
        {
           
            if(value>=10000)
            {
                this.valueChangeHandler(event);
                this.changeClass(name,false);
               // event.target.classList.remove('Mui-error');
            }else
            {
                this.changeClass(name,true);
               // event.target.classList.add('Mui-error');
            }
        }   

        if(name === "cash_deposit")
        {
           
            if(value>=500)
            {
                this.valueChangeHandler(event);
                this.changeClass(name,false);
                
            }else
            {
                this.changeClass(name,true);
            }
        } 
        if(name === "lvr")
        {
           
            if(value<=98)
            {
                
                this.valueChangeHandler(event);
                this.changeClass(name,false);
                
            }else
            {    
                if(value>98)
                {
                    event.target.value = 98;
                }
                
                this.valueChangeHandler(event);       
                this.changeClass(name,true);
            }

        } 
       
        
    }



    valueChangeHandler = (event) => {
        let name = event.target.name;
        let value = event.target.value;
        let type = event.target.type;
        let updateState = { ...this.state }
        if(name === "lmi_type")
        {
           
            if(value === "none")
            {
               
                updateState['lmi'] = 0; 
            }else{
                
                let lvr_value = parseFloat(this.state.lvr);
                
                let lmi = 0;
                if (lvr_value >= 81 && lvr_value <= 84) {
                    lmi = 1;
                }
                else if (lvr_value >= 85 && lvr_value <= 89) {
                    lmi = 1.7;
                }
                else if (lvr_value === 90) {
                    lmi = 2.25;
                }
                else if (lvr_value >= 91 && lvr_value <= 94) {
                    lmi = 4;
                }
                else if (lvr_value >= 95 && lvr_value <= 98) {
                    lmi = 5;
                }
               
                updateState['lmi'] = lmi;
            }
        }
        


        if (name === "lvr") {
            if (!isNaN(value)) {
                value = parseFloat(value)
                let lmi = 0;
                if (value >= 81 && value <= 84) {
                    lmi = 1;
                }
                else if (value >= 85 && value <= 89) {
                    lmi = 1.7;
                }
                else if (value === 90) {
                    lmi = 2.25;
                }
                else if (value >= 91 && value <= 94) {
                    lmi = 4;
                }
                else if (value >= 95 && value <= 98) {
                    lmi = 5;
                }
                updateState['lmi'] = lmi;
            }
        }
        if (name === "is_property_off_the_loan") {
            updateState[name] = value === "false" ? false : true;

            if(value === 'true' )
            {
                updateState['property_due_to_omplete'] = 18;
                updateState['minimum_monthly_amount_payable'] = 1500;
            }
            else
            {
                updateState['property_due_to_omplete'] = 0;
                updateState['minimum_monthly_amount_payable'] = 0;
            }
        }
        if (name === "repayment_type") {
            if (value === "io") {
                updateState["loan_term"] = "5";
            }
            else {
                updateState["loan_term"] = "30";
            }
        }

        if (name === "loan_term") {
            if (value !== "") {
                if (this.state.repayment_type === "io" && (parseInt(value) <= 0 || parseInt(value) > 5)) {
                    return false;
                }
                else if (this.state.repayment_type === "pi" && (parseInt(value) <= 0 || parseInt(value) > 30)) {
                    return false;
                }
            }
            else {
                value = "1";
            }
        }

        /*if (name === "is_property_off_the_loan") {
            updateState[name] = value === "false" ? false : true;
        }*/

        if (value === "") {
           // value = "0";
        }

        if (name === "property_purchase_price") {
            updateState["property_value"] = value;
        }

        if (name === "is_property_off_the_loan") {
            value = value === "false" ? false : true;
        }

        if (name === "purchase_type") {
           if(value === "first_home_owner")
                updateState["first_home_grant"] = "10000";
            else
                updateState["first_home_grant"] = "0";     
        }
       
        updateState[name] = value;
        this.setState({
            ...updateState
        });
    }

    getLmiValue = () => {
        let lmi_value = "0";
        if (this.state.lmi_type !== "none") {
            let  loan_amount = parseFloat(this.state.property_value) * parseFloat(this.state.lvr) / 100;
            lmi_value = parseFloat(parseFloat(loan_amount) * parseFloat(this.state.lmi) / 100).toFixed(2);
        }
        return Math.round(lmi_value);
    }

    getLoanAmount = () => {
        let loan_amount = "";
        loan_amount = parseFloat(this.state.property_value) * parseFloat(this.state.lvr) / 100;
        if (this.state.lmi_type === "plus_loan") {
            loan_amount = loan_amount + parseFloat(this.getLmiValue());
        }
        return Math.round(loan_amount);
    }

    getAvailableFund = () => {
        let available_fund = "";
        available_fund = parseFloat(parseFloat(this.getLoanAmount()) - parseFloat(this.getLmiValue())).toFixed(2);
        return Math.round(available_fund);
    }

    getMonthlyPayment = () => {
        let monthly_payment = "";
        if (this.state.repayment_type === "io") {
            monthly_payment = this.calrepayIO()
        }
        else {
            monthly_payment = this.calrepayPI();
        }

        if(monthly_payment > 0)
            this.state.monthly_payment = monthly_payment;

        return monthly_payment;
    }

    calrepayPI = () => {
        let rate = parseFloat(this.state.interest_rate);
        let loan_term = parseInt(this.state.loan_term);
        let loanamount = parseInt(this.getLoanAmount());
        let term = parseInt(this.state.payment_frequency);
        if (rate == 0) {
            var pay = loanamount / (loan_term * term);
        }
        else {
            var n = loan_term * term;
            var c = rate / (100 * term);
            var number1 = c * Math.pow(1 + c, n);
            var number2 = Math.pow(1 + c, n) - 1;
            var pay = loanamount * (number1 / number2);
        }

        return Math.round(pay);
    }

    calrepayIO = () => {
        let rate = parseFloat(this.state.interest_rate);
        let loanamount = parseInt(this.getLoanAmount());

        //commented below line as need to use monthly/fornightly/weekly
        //var pay = (rate * loanamount) / (100 * 12);

        //added below 2 line as need to use monthly/fornightly/weekly
        let term = parseInt(this.state.payment_frequency);
        var pay = (rate * loanamount) / (100 * term);

        return Math.round(pay);
    }

    getOnlyMonthlyPayment = () => {
        let monthly_payment = "";
        if (this.state.repayment_type === "io") {
            monthly_payment = this.calrepayIO()
        }
        else {
            monthly_payment = this.calmonthlyrepayPI();
        }
        return monthly_payment;
    }

    calmonthlyrepayPI = () => {
        let rate = parseFloat(this.state.interest_rate);
        let loan_term = parseInt(this.state.loan_term);
        let loanamount = parseInt(this.getLoanAmount());
        let term = parseInt(this.state.payment_frequency_monthly);
        if (rate == 0) {
            var pay = loanamount / (loan_term * term);
        }
        else {
            var n = loan_term * term;
            var c = rate / (100 * term);
            var number1 = c * Math.pow(1 + c, n);
            var number2 = Math.pow(1 + c, n) - 1;
            var pay = loanamount * (number1 / number2);
        }

        return Math.round(pay);
    }

    getPropertyVarianceAmount = () => {
        let variance_amount = parseFloat(this.state.property_purchase_price) - parseFloat(this.state.property_value);
        return Math.round(variance_amount);
    }

    getPropertPricePercentage = () => {
        let per = "0";
        if (parseFloat(this.state.property_purchase_price) > 0) {
            per = parseFloat(this.state.cash_deposit) / parseFloat(this.state.property_purchase_price) * 100;
        }
        return parseFloat(per).toFixed(2);
    }

    getNeededDepositLoanAmount = () => {
        let needed_amount = "";
        //needed_amount = ((100 - parseFloat(this.state.lvr)) / 100) * parseFloat(this.state.property_value) + (parseFloat(this.state.property_purchase_price) - parseFloat(this.state.property_value));
        //needed_amount = (((100 - parseFloat(this.state.lvr)) / 100) * parseFloat(this.state.property_purchase_price)) + (this.getPropertyVarianceAmount()) + this.getLmiValue();

        //new formula
        needed_amount =  parseFloat(this.state.property_purchase_price) - this.getAvailableFund();
        return Math.round(needed_amount);
    }

    getDdaAmount = () => {
        let dda_amount = "";
        dda_amount = this.getNeededDepositLoanAmount() - parseFloat(this.state.first_home_grant) - parseFloat(this.state.other_grant) - parseFloat(this.state.cash_deposit);
        return Math.round(dda_amount);
    }

    getDdaPercentage = () => {
        let dda_percentage = "";
        
        dda_percentage = (this.getDdaAmount() * 100) / parseFloat(this.state.property_purchase_price);
        return parseFloat(dda_percentage).toFixed(2);
    }

    getAdditionalFunds = () => {
        let additional_funds = "";
        additional_funds = parseInt(this.state.property_due_to_omplete) * parseFloat(this.state.minimum_monthly_amount_payable);
        return Math.round(additional_funds);
    }

    getBalanceAfterSettlement = () => {
        let settlement_amount = "";
        settlement_amount = this.getDdaAmount() - this.getAdditionalFunds() - parseFloat(this.state.other_incentives);
        return Math.round(settlement_amount);
    }

    getPayableWithin = () => {
        let payable_within = "";
        payable_within = parseInt(this.state.interest_free_term) - parseInt(this.state.property_due_to_omplete);
        return parseInt(payable_within);
    }

    getOnlyMonthlyInterestPayment = () => {
        let only_monthly_interest_payment = "";
        only_monthly_interest_payment = (this.getBalanceAfterSettlement() / this.getPayableWithin()) * 12 /  parseInt(this.state.payment_frequency_monthly);  

       

        return parseFloat(only_monthly_interest_payment).toFixed(2);
    }

    getParseValueByPaymentFrequency=(value)=>{
        let newvalue = value * 12 /  parseInt(this.state.payment_frequency);  
        
        if(newvalue >= 0)
            return parseFloat(newvalue).toFixed(2);
        else
            return 0;
    }


    getMonthlyInterestPayment = () => {
        let monthly_interest_payment = "";
        monthly_interest_payment = (this.getBalanceAfterSettlement() / this.getPayableWithin()) * 12 /  parseInt(this.state.payment_frequency);  

        if(monthly_interest_payment > 0)
            this.state.monthly_interest_payment = monthly_interest_payment;

        return parseFloat(monthly_interest_payment).toFixed(2);
    }

    getMonthlyInstallment = () => {
        
        let monthly_installment = "";
        let monthly_payment = parseFloat(this.getMonthlyPayment())
        let monthly_interest_payment = parseFloat(this.getMonthlyInterestPayment());

        if(monthly_interest_payment > 0)
        {
            monthly_installment = monthly_payment + monthly_interest_payment;

            return parseFloat(monthly_installment).toFixed(2);
        }
        else
        {
            
            monthly_installment = monthly_payment ;
            return parseFloat(monthly_installment).toFixed(2);
        }         
    }

    getInstallmentLabel = () => {
        let label = "Monthly";
        if(this.state.payment_frequency === "26") {
            label = "Fortnightly";
        }
        else if(this.state.payment_frequency === "52") {
            label = "Weekly";
        }

        return label;
    }

    getInstallmentLabelTop = () => {
        let label = "monthly";
        if(this.state.payment_frequency === "26") {
            label = "fortnightly";
        }
        else if(this.state.payment_frequency === "52") {
            label = "weekly";
        }

        return label;
    }

}

export default AffordAssistCalApp;