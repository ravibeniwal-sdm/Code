import React from "react";
import { Box, Card, CardContent, Container, Divider, FormControl, FormHelperText, Input, InputAdornment, InputLabel, MenuItem, Select, TextField } from "@material-ui/core";


import HomePageCalc from "../calculator/HomePageCalc";
import AffordAssistCalApp from "../controller/AffordAssistCalApp";

import AffordAssistDDACal from "../calculator/AffordAssistDDACal";

import PaymentCalcDetail from "./PaymentCalcDetail";
import PaymentCalcForm from "./PaymentCalcForm";
import PaymentCalcHeader from "./PaymentCalcHeader";




class PaymentCalc extends AffordAssistCalApp {
    render() {
        const styles = {
           
            root: {
                padding:'10px',
                fontFamily:'Arial',
                width: '100%',
            }
            
        };

        let calculated_values = {};
        calculated_values['lmi_value'] = this.getLmiValue();
        calculated_values["loan_amount"] = this.getLoanAmount();
        calculated_values["available_fund"] = this.getAvailableFund();
        calculated_values["monthly_payment"] = this.getMonthlyPayment();
        calculated_values["only_monthly_payment"] = this.getOnlyMonthlyPayment();
        calculated_values["variance_amount"] = this.getPropertyVarianceAmount();
        calculated_values["propert_price_percentage"] = this.getPropertPricePercentage();
        calculated_values["needed_loan_deposit_amount"] = this.getNeededDepositLoanAmount();
        calculated_values['dda_amount'] = this.getDdaAmount();
        calculated_values['dda_percentage'] = this.getDdaPercentage();
        calculated_values['additional_funds'] = this.getAdditionalFunds();
        calculated_values['settlement_amount'] = this.getBalanceAfterSettlement();
        calculated_values['payable_within'] = this.getPayableWithin();
        calculated_values['monthly_interest_payment'] = this.getMonthlyInterestPayment();
        calculated_values['only_monthly_interest_payment'] = this.getOnlyMonthlyInterestPayment();
        calculated_values['monthly_installment'] = this.getMonthlyInstallment();
        calculated_values['installment_label'] = this.getInstallmentLabel();
        calculated_values['installment_label_top'] = this.getInstallmentLabelTop();
        
        
        return (
            <Container style={styles.root} component="main" maxWidth="lg">
                <PaymentCalcHeader/>
                <PaymentCalcForm  
                    parentState={this.state} 
                    valueChangeHandler={this.valueChangeHandler}
                    checkMinMaxValidator={this.checkMinMaxValidator}
                    setMessage={this.setMessage}
                    removeMessage={this.removeMessage}
                    calculated_values={calculated_values} 
                />
                <PaymentCalcDetail  
                    parentState={this.state}
                    calculated_values={calculated_values}
                    getParseValueByPaymentFrequency={this.getParseValueByPaymentFrequency}
                />

                <HomePageCalc
                    parentState={this.state}
                    valueChangeHandler={this.valueChangeHandler}
                    checkMinMaxValidator={this.checkMinMaxValidator}
                    setMessage={this.setMessage}
                    removeMessage={this.removeMessage}
                    calculated_values={calculated_values}
                />
                <AffordAssistDDACal
                    parentState={this.state}
                    valueChangeHandler={this.valueChangeHandler}
                    checkMinMaxValidator={this.checkMinMaxValidator}
                    setMessage={this.setMessage}
                    removeMessage={this.removeMessage}
                    calculated_values={calculated_values}
                />
            </Container>
        )
    }
}

export default PaymentCalc;