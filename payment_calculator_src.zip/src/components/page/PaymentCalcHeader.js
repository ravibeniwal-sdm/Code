import React from "react";
import { makeStyles, createStyles, Theme } from "@material-ui/core/styles";

import Grid from "@material-ui/core/Grid";



const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      flexGrow: 1,
      padding: theme.spacing(1),
      fontFamily:'Arial',
      marginBottom: theme.spacing(3)
    },
    paper: {
      padding: theme.spacing(2),
      textAlign: "center",
      color: theme.palette.text.secondary
    },
    textbox: {
        width: '100%',
    },
    textboxRadio: {
        width: '40%',
    },
    center: {
      justifyContent: 'center',
      alignItems: 'center',
      display: 'flex',
      margin: theme.spacing(1),
  },
  title: {
   
    [theme.breakpoints.down('sm')]: {
      fontSize: 18,
      padding: theme.spacing(1)
    },
    [theme.breakpoints.down('md')]: {
      fontSize: 20,
      padding: theme.spacing(1)
    },
    [theme.breakpoints.down('lg')]: {
      fontSize: 24,
      padding: theme.spacing(1)
    },
   
    
    },
  subtitle: {
   
    [theme.breakpoints.down('sm')]: {
      fontSize: 14,
    
    },
    [theme.breakpoints.down('md')]: {
      fontSize: 16,
      
    },
    [theme.breakpoints.down('lg')]: {
      fontSize: 18,
     
    },

    
    },
   bold:{
    fontWeight: 'bold'
   },
   alignLeft: {
    textAlign: 'left',    
    },
    primaryColor: {
      color: '#008751'
    },
    box:{
                backgroundColor: '#008751',
                color: '#fff',
              
                textAlign: 'center',
                padding: theme.spacing(2) 
    },
    spacing:{
      padding: theme.spacing(1)
    },
    cardspacing:{
      marginTop: theme.spacing(1)
    }, 
    blue: {
      color: 'blue'
      
    } ,
    fourteenFontSize: {
      fontSize:'14px'
    },
    sixteenFontSize: {
      fontSize:'16px'
    },
    eighteenFontSize: {
      fontSize:'18px'
    }
    
    
  })
);

export default function PaymentCalcForm() {
  const classes = useStyles();

  return (
    <Grid container spacing={1}>
          
          <Grid className={[classes.center,classes.subtitle,classes.sixteenFontSize]} container item xs={12} spacing={3}>
             Estimate your total monthly home loan and AffordAssist deferred deposit agreement (DDA) payments.
          </Grid>
    </Grid>
  );
 
}
