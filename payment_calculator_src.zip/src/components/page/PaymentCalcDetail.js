import React from "react";
import { makeStyles, createStyles, Theme } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import {Radio, Box, Card, CardContent, Container, Divider, FormControl, FormHelperText, Input, InputAdornment, InputLabel, MenuItem, Select, TextField } from "@material-ui/core";

import CurrencyFormat from 'react-currency-format';

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      flexGrow: 1,
      padding: theme.spacing(1),
      fontFamily:'Arial',
      marginBottom: theme.spacing(3)
    },
    paper: {
      padding: theme.spacing(2),
      textAlign: "center",
      color: theme.palette.text.secondary
    },
    textbox: {
        width: '100%',
    },
    textboxRadio: {
        width: '40%',
    },
    center: {
      justifyContent: 'center',
      alignItems: 'center',
      display: 'flex',
      margin: theme.spacing(1),
  },
  title: {
   
    [theme.breakpoints.down('sm')]: {
      fontSize: 18,
      padding: theme.spacing(1)
    },
    [theme.breakpoints.down('md')]: {
      fontSize: 20,
      padding: theme.spacing(1)
    },
    [theme.breakpoints.down('lg')]: {
      fontSize: 24,
      padding: theme.spacing(1)
    },
   
    
    },
  subtitle: {
   
    [theme.breakpoints.down('sm')]: {
      fontSize: 14,
    
    },
    [theme.breakpoints.down('md')]: {
      fontSize: 16,
      
    },
    [theme.breakpoints.down('lg')]: {
      fontSize: 18,
     
    },

    
    },
   bold:{
    fontWeight: 'bold'
   },
   alignLeft: {
    textAlign: 'left',    
    },
    primaryColor: {
      color: '#008751'
    },
    box:{
        backgroundColor: '#008751',
        color: '#fff',
      
        textAlign: 'center',
        padding: theme.spacing(2) 
    },
    spacing:{
      padding: theme.spacing(1)
    },
    cardspacing:{
      marginTop: theme.spacing(1)
    }, 
    blue: {
      color: 'blue'
      
    },
    fourteenFontSize: {
      fontSize:'14px'
    },
    sixteenFontSize: {
      fontSize:'16px'
    },
    eighteenFontSize: {
      fontSize:'18px'
    },
    brownColor: {
      color: 'brown'
    },
    paddingLeft: {
      paddingLeft: '20px'
    },
    blackColor: {
      color: 'black'
    },
    greyColor: {
      color: 'grey'
    },
    greenColor: {
      color: '#008751 !important'
    },
  })
);

export default function PaymentCalcDetail(props) {
  const classes = useStyles();

    
  function PaymentDuringConstruction() {
    return (
      <React.Fragment>
         <Grid className={[classes.alignLeft,classes.title,classes.bold,classes.primaryColor,classes.sixteenFontSize]}  xs={12} sm={12}>
                    Payments during construction
          </Grid>
            <Divider  />

          <Grid className={[classes.alignLeft,classes.subtitle]} container xs={12} sm={12}>
            
              <Grid container xs={12} sm={4}>
                    <Grid className={[classes.spacing,classes.sixteenFontSize]} item xs={12} sm={12}>
                      Home Loan
                      
                    </Grid>
                    <Grid className={[classes.spacing]} item xs={12} sm={12}>
                     
                    </Grid>
                    <Grid className={[classes.spacing,classes.title,classes.sixteenFontSize]} item xs={12} sm={12}>
                        $ 0
                    </Grid>
                    <Grid  className={[classes.spacing,classes.bold,classes.sixteenFontSize]} item xs={12} sm={12}>
                      {props.calculated_values.installment_label}  payments
                    </Grid>
                  
                </Grid> 
           
              
                <Grid container xs={12} sm={6}>
                    <Grid className={[classes.spacing,classes.sixteenFontSize]} item xs={12} sm={12}>
                      AffordAssist deposit solution 
                      
                    </Grid>
                    <Grid className={[classes.spacing,classes.sixteenFontSize]} item xs={12} sm={12}>
                      DDA, {props.parentState.property_due_to_omplete} months
                      
                    </Grid>
                    <Grid className={[classes.spacing,classes.title,,classes.sixteenFontSize]} item xs={12} sm={12}>
                        <CurrencyFormat value={props.getParseValueByPaymentFrequency(props.parentState.minimum_monthly_amount_payable)} displayType={'text'} thousandSeparator={true} prefix={'$'} />
                    </Grid>
                    <Grid className={[classes.spacing,classes.bold,classes.sixteenFontSize]} item xs={12} sm={12}>
                      {props.calculated_values.installment_label} interest free payments
                    </Grid>
                  
                </Grid> 
               
              
                <Grid container xs={12} sm={2}>
                    <Grid className={[classes.spacing,classes.bold,classes.primaryColor,classes.sixteenFontSize]} item xs={12} sm={12}>
                      Total
                      
                    </Grid>
                    
                    <Grid className={[classes.spacing,classes.bold,classes.primaryColor,classes.sixteenFontSize]} item xs={12} sm={12}>
                        <CurrencyFormat value={props.getParseValueByPaymentFrequency(props.parentState.minimum_monthly_amount_payable)} displayType={'text'} thousandSeparator={true} prefix={'$'} />
                    </Grid>
                    <Grid className={[classes.spacing,classes.bold]} item xs={12} sm={12}>
                      
                    </Grid>
                  
                </Grid> 
              
          </Grid>
                     
      </React.Fragment>
    );
  }

  function PaymentAfterCompletion() {
    return (
      <React.Fragment>
         <Grid className={[classes.alignLeft,classes.title,classes.bold,classes.primaryColor,classes.sixteenFontSize]}  xs={12} sm={12}>
                    Payments after completion
          </Grid>
            <Divider  />

          <Grid className={[classes.alignLeft,classes.subtitle]} container xs={12} sm={12}>
            
              <Grid container xs={12} sm={4}>
                    <Grid className={[classes.spacing,classes.sixteenFontSize]} item xs={12} sm={12}>
                      Home Loan
                      
                    </Grid>
                    <Grid className={[classes.spacing]} item xs={12} sm={12}>
                     
                    </Grid>
                    <Grid className={[classes.spacing,classes.title,classes.sixteenFontSize]} item xs={12} sm={12}>
                        <CurrencyFormat value={props.calculated_values['monthly_payment']<0?0:props.calculated_values['monthly_payment']} displayType={'text'} thousandSeparator={true} prefix={'$'} />
                    </Grid>
                    <Grid  className={[classes.spacing,classes.bold,classes.sixteenFontSize]} item xs={12} sm={12}>
                      {props.calculated_values.installment_label}  payments
                    </Grid>
                  
                </Grid> 
           
              
                <Grid container xs={12} sm={6}>
                    <Grid className={[classes.spacing,classes.sixteenFontSize]} item xs={12} sm={12}>
                      AffordAssist deposit solution 
                      
                    </Grid>
                    <Grid className={[classes.spacing,classes.sixteenFontSize]} item xs={12} sm={12}>
                      DDA, {props.calculated_values['payable_within']<0?0:props.calculated_values['payable_within']} months
                      
                    </Grid>
                    <Grid className={[classes.spacing,classes.title,classes.sixteenFontSize]} item xs={12} sm={12}>
                        <CurrencyFormat value={props.calculated_values['monthly_interest_payment']<0?0:props.calculated_values['monthly_interest_payment']} displayType={'text'} thousandSeparator={true} prefix={'$'} />
                    </Grid>
                    <Grid className={[classes.spacing,classes.bold,classes.sixteenFontSize]} item xs={12} sm={12}>
                      {props.calculated_values.installment_label} interest free payments
                    </Grid>
                  
                </Grid> 
               
              
                <Grid container xs={12} sm={2}>
                    <Grid className={[classes.spacing,classes.bold,classes.primaryColor,classes.sixteenFontSize]} item xs={12} sm={12}>
                      Total
                      
                    </Grid>
                    
                    <Grid className={[classes.spacing,classes.bold,classes.primaryColor,classes.sixteenFontSize]} item xs={12} sm={12}>
                        <CurrencyFormat value={props.calculated_values['monthly_installment']<0?0:props.calculated_values['monthly_installment']} displayType={'text'} thousandSeparator={true} prefix={'$'} />
                    </Grid>
                    
                  
                </Grid> 
              
          </Grid>
                     
      </React.Fragment>
    );

    
  }

  function Subtitle() {
    return (
      <React.Fragment>
          <Grid className={[classes.center,classes.subtitle,classes.blackColor,classes.fourteenFontSize]} container item xs={12} spacing={3}>
          Create your personal scenarios below, discover how affordable your first-home could be.
          </Grid>
          <Grid className={[classes.center,classes.subtitle,classes.blackColor,classes.fourteenFontSize]} container item xs={12} spacing={3}>
         
          Or a lifeline for buyers and sellers struggling to settle existing purchase agreements.
          
          </Grid>
          <Grid className={[classes.center,classes.subtitle,classes.blackColor,classes.fourteenFontSize]} container item xs={12} spacing={3}>
           You may also print or save a Scenario Report.
          </Grid>

          <Grid className={[classes.center,classes.subtitle,classes.greyColor,classes.fourteenFontSize]} container item xs={12} spacing={3}>
          The default values are an example only, amend as required
          </Grid>

          <Grid className={[classes.center,classes.greenColor,classes.fourteenFontSize]} container item xs={12} spacing={3}>
            <a href="http://www.affordassist.com/conditions-of-use/" target="_blank">Conditions of use </a> 
            <a href="https://www.affordassist.com/glossary-tips" target="_blank" className={[classes.paddingLeft]}>Glossary + Tips</a>
          </Grid>

      </React.Fragment>
    );

    
  }



  return (
    <Container className={classes.root} component="main" maxWidth="lg">
     <Card className={[classes.spacing,classes.cardspacing]}>
            <PaymentDuringConstruction/>
      </Card>
      <Card className={[classes.spacing,classes.cardspacing]}>
          <PaymentAfterCompletion/>
      </Card>

      <Grid className={[classes.spacing,classes.cardspacing]}>
            <Subtitle/>
      </Grid>
      
    </Container>
  );
}
