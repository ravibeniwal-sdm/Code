import React from "react";
import { makeStyles, createStyles, Theme } from "@material-ui/core/styles";

import Grid from "@material-ui/core/Grid";
import {Radio, Box, Card, CardContent, Container, Divider, FormControl, FormHelperText, Input, InputAdornment, InputLabel, MenuItem, Select, TextField } from "@material-ui/core";

import CurrencyFormat from 'react-currency-format';
import NumberFormatCustom from "../calculator/format/NumberFormatCustom";
const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      flexGrow: 1,
      padding: theme.spacing(1),
      fontFamily:'Arial',
      marginBottom: theme.spacing(3)
    },
    paper: {
      padding: theme.spacing(2),
      textAlign: "center",
      color: theme.palette.text.secondary
    },
    textbox: {
        width: '100%',
    },
    textboxRadio: {
        width: '40%',
    },
    center: {
      justifyContent: 'center',
      alignItems: 'center',
      display: 'flex',
      margin: theme.spacing(1),
  },
  title: {
   
    [theme.breakpoints.down('sm')]: {
      fontSize: 18,
      padding: theme.spacing(1)
    },
    [theme.breakpoints.down('md')]: {
      fontSize: 20,
      padding: theme.spacing(1)
    },
    [theme.breakpoints.down('lg')]: {
      fontSize: 24,
      padding: theme.spacing(1)
    },
   
    
    },
  subtitle: {
   
    [theme.breakpoints.down('sm')]: {
      fontSize: 14,
    
    },
    [theme.breakpoints.down('md')]: {
      fontSize: 16,
      
    },
    [theme.breakpoints.down('lg')]: {
      fontSize: 18,
     
    },

    
    },
   bold:{
    fontWeight: 'bold'
   },
   alignLeft: {
    textAlign: 'left',    
    },
    primaryColor: {
      color: '#008751'
    },
    box:{
                backgroundColor: '#008751',
                color: '#fff',
                borderRadius:'4px',
                textAlign: 'center',
                padding: theme.spacing(2) 
    },
    spacing:{
      padding: theme.spacing(1)
    },
    cardspacing:{
      marginTop: theme.spacing(1)
    }, 
    blue: {
      color: 'blue'
      
    },
    marginTop: {
      marginTop:'20px'
    },
  
    fourteenFontSize: {
      fontSize:'14px'
    },
    sixteenFontSize: {
      fontSize:'16px'
    },
    eighteenFontSize: {
      fontSize:'18px'
    }
    
    
  })
);

export default function PaymentCalcForm(props) {
  const classes = useStyles();

  return (
    <Container className={classes.root} component="main" maxWidth="lg">
    <Grid container spacing={1}>
      <Grid item xs={12} sm={4}>
      
         <InputLabel >Property purchase price</InputLabel>
            
            <TextField
            
            id="property_purchase_price"
            value={props.parentState.property_purchase_price}
            onChange={props.checkMinMaxValidator}
            name="property_purchase_price"
            onFocus={props.setMessage}   
            onBlur={props.removeMessage}   
            helperText={props.parentState.property_purchase_price_helpText ? "Value may be above $10,000.":""}
            InputProps={{startAdornment: (
                <InputAdornment position="start">
                  $
                </InputAdornment>
              ),inputComponent: NumberFormatCustom}}/>


                      
      </Grid>
      <Grid item xs={12} sm={4}>
            <InputLabel >Your cash deposit</InputLabel>

            <TextField
            
             id="cash_deposit"
             name="cash_deposit"
            
             value={props.parentState.cash_deposit}
             onFocus={props.setMessage}   
             onBlur={props.removeMessage}   
             onChange={props.checkMinMaxValidator}
             helperText={props.parentState.cash_deposit_helpText ? "Value may be above $500.":""}
             InputProps={{startAdornment: (
                <InputAdornment position="start">
                  $
                </InputAdornment>
              ),inputComponent: NumberFormatCustom}}/>
             
      </Grid>
     
      <Grid item xs={12} sm={4}>
            <InputLabel >Payments frequency</InputLabel>
            <TextField
                
                select
                name="payment_frequency"
                id="demo-simple-select-outlined"
                value={props.parentState.payment_frequency}
                onChange={props.valueChangeHandler}
                SelectProps={{
                    native: true,
                }}                                
                >
                <option value="12">Monthly</option>
                <option value="26">Fortnightly</option>
                <option value="52">Weekly</option>
                   
                
            </TextField>
      </Grid>
      <Grid className={[classes.alignLeft,classes.title,classes.box,classes.subtitle,classes.marginTop,classes.sixteenFontSize]}  xs={12} sm={12}>
            Your Estimated Payments would be <b> <CurrencyFormat value={props.calculated_values['monthly_installment']<0?0:props.calculated_values['monthly_installment']} displayType={'text'} thousandSeparator={true} prefix={'$'} /> </b> {props.calculated_values.installment_label_top}
      </Grid>          
    
    
    </Grid>
    </Container>
  );
 
}
