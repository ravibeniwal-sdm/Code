import React, { Component } from "react";
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Accordion, AccordionSummary, AccordionDetails, Typography, Box, InputAdornment, OutlinedInput, Select, MenuItem, Checkbox, Radio, Divider, TextField } from '@material-ui/core';

import CurrencyFormat from 'react-currency-format';

import NumberFormatCustom from "./format/NumberFormatCustom";
import AANumberFormat from "./format/AANumberFormat";

import AffordAssistDDACalDetail from "./AffordAssistDDACalDetail";
class AffordAssistDDACal extends Component {

    state = {
        isExpanded: false
    }
    onExpand = (event, isExpanded) => {
       
        this.setState({
            isExpanded: isExpanded
        });
    };
    render() {
        const styles = {
            header: {
                borderBottom: '1px solid #008751',
                margin: '0px 16px',
                padding: '0px'
            },
            header_title: {
                fontSize: '16px',
                color: '#008751',
                fontWeight: '500'
            },
            expandIcon: {
                color: '#008751'
            },
            form_container: {
                display: 'flex',
                flexDirection: 'column',
                width: '100%'
            },
            input_box: {
                display: 'flex',
                width: '100%',
                justifyConent: 'space-between',
                padding: '8px 0px'
            },
            input_label: {
                width: "25%",
                display: 'flex',
                fontSize: '13px',
                alignItems: 'center'
            },
            input_label_bold: {
                width: "25%",
                display: 'flex',
                fontSize: '13px',
                fontWeight: '600',
                alignItems: 'center'
            },
            textfield: {
                width: '30%',
                height: '35px',
                fontSize: '14px'
            },
            checkbox: {
                // width: '30%',
                // height: '35px',
                fontSize: '14px',
                display: 'flex',
                justifyContent: 'flex-start',
                alignItems: 'flex-start',
            },
            radio_box: {
                textAlign: 'center'
            },
            text_lable: {
                fontSize: '16px'
            },
            text_lable_bold: {
                fontSize: '16px',
                fontWeight: '600',
            },
            sponser_box: {
                backgroundColor: '#ededed',
                borderRadius: '4px',
                display: 'flex',
                flexDirection: 'column',
                padding: '10px',
                paddingBottom: '0px'
            },
            sponser_block: {
                display: 'flex',
                flexDirection: 'row',
                paddingBottom: '10px'
            },
            sponser_box_blue: {
                height: '20px',
                width: '20px',
                backgroundColor: '#0041ff'
            },
            sponser_box_red: {
                height: '20px',
                width: '20px',
                backgroundColor: '#990d00'
            },

            summary_box: {
                color: '#000',
                display: 'flex',
                flexDirection: 'row',
                paddingTop: 10,
            },
            sponser_tag: {
                fontSize: '14px',
                padding: '0px 16px'
            },
            dividercontrol: {
                marginTop: 20,
                color: '#008751',

            },
            property_summary_title: {
                marginTop: 20,
                fontWeight: 'bold'

            },
            property_summary_detail: {
                marginLeft: 20,
            }

        };

        return (
            <Accordion onChange={this.onExpand} >
                <AccordionSummary
                    style={this.state.isExpanded ? styles.header : {}}
                    expandIcon={<ExpandMoreIcon style={styles.expandIcon} />}
                    aria-controls="panel1bh-content"
                    id="panel1bh-header"
                >
                    <Typography style={styles.header_title}>AffordAssist Property-Deposit Solution + Payments</Typography>
                </AccordionSummary>
                <AccordionDetails>
                    <AffordAssistDDACalDetail {...this.props}/>
                </AccordionDetails>
            </Accordion>
        );
    }
}

export default AffordAssistDDACal;