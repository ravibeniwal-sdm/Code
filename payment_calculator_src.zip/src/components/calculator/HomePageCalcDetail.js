import React from "react";
import { makeStyles, createStyles, Theme } from "@material-ui/core/styles";

import Grid from "@material-ui/core/Grid";
import {Radio, Box, Card, CardContent, Container, Divider, FormControl, FormHelperText, Input, InputAdornment, InputLabel, MenuItem, Select, TextField,Typography } from "@material-ui/core";

import CurrencyFormat from 'react-currency-format';
import NumberFormatCustom from "./format/NumberFormatCustom";
import AANumberFormat from "./format/AANumberFormat";
const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      flexGrow: 1,
      padding: theme.spacing(1)
    },
    paper: {
      padding: theme.spacing(2),
      textAlign: "center",
      color: theme.palette.text.secondary
    },
    textbox: {
        width: '100%',
        fontSize :"14px",
        color:"black"
    },
    textboxRadio: {
        width: '40%',
    },
    formcontrol: {
        padding: '8px 0px',
        fontSize :"13px",
        alignItems: 'center',
        display: 'flex',
        width: '100%',
        justifyConent: 'space-between',
    },
    bold:{
        fontWeight: 'bold'
       },
    sponsorBox:{
        backgroundColor: '#ededed',
        borderRadius: '4px',
        display: 'flex',
        padding: '10px',
        paddingBottom: '10px'
       },
    sponser_box_blue: {
            height: '20px',
            width: '20px',
            backgroundColor: '#0041ff',
            clear:'both',
            float:'left',

        },
    sponser_box_red: {
            height: '20px',
            width: '20px',
            backgroundColor: '#990d00',
            clear:'both',
            float:'left',
        },
    marginRight:{
        marginRight:'10px'
    },
    paddingTop:{
        paddingTop:'10px'
    },
    paddingBottom:{
        paddingBottom:'20px'
    },
    textAlignCenter:{
        textAlign:'center'
    },
    fontStyleItalic:{
        fontStyle:'italic'
    },
    fontColorBlue:{
        color:'blue !important'
    },
    
    fourteenFontSize: {
      fontSize:'14px'
    },
     lmiTextbox:{
        width:"40% !important",
        paddingLeft: "14px"
    }

  })
);

 function FormRowMain(props) {
    const classes = useStyles();

    let conditional_statement_one = '';
        
    if(props.parentState.cash_deposit < props.calculated_values.needed_loan_deposit_amount)
        conditional_statement_one = "Based on the above scenario, your cash deposit is less than the loan-deposit required by a lender to obtain a home loan.";




    return (
      <React.Fragment>
      <Container className={classes.root} component="main" maxWidth="lg">
      <Grid className={classes.formcontrol} container item xs={12} spacing={3}>
            <Grid item xs={12} sm={3}>
                <Typography  className={classes.textbox} >Property value</Typography>                        
            </Grid>
            <Grid item xs={12} sm={3}>            
                    <TextField
                             
                      id="standard-start-adornment"
                      name="property_value"
                      value={props.parentState.property_value}
                      onChange={props.valueChangeHandler}
                     InputProps={{startAdornment: (
                        <InputAdornment position="start">
                          $
                        </InputAdornment>
                      ),inputComponent: NumberFormatCustom}}/>
            </Grid>
       </Grid> 
       <Grid className={classes.formcontrol} container item xs={12} spacing={3}>
            <Grid item xs={12} sm={3}>
                <Typography  className={classes.textbox} >Loan (LVR)</Typography>                        
            </Grid>
            <Grid item xs={12} sm={3}>            
                        <TextField
                           
                            id="lvr"
                            value={props.parentState.lvr}
                            onChange={props.checkMinMaxValidator}
                            name="lvr"
                            onFocus={props.setMessage}   
                            
                            onBlurCapture={props.removeMessage}   
                            helperText={props.parentState.lvr_helpText ? "Currenty LVR of 99% and above are nor consider. Maximum 98%.":""}
                            InputProps={{endAdornment: (
                                <InputAdornment position="end">
                                  %
                                </InputAdornment>
                              ),inputComponent: NumberFormatCustom}}/>
            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item xs={12} spacing={3}>
            <Grid item xs={12} sm={3}>
                <Typography  className={classes.textbox} >Loan amount</Typography>                        
            </Grid>
            <Grid item xs={12} sm={3}>            
                <Typography className={classes.textbox}><CurrencyFormat value={props.calculated_values.loan_amount} displayType={'text'} thousandSeparator={true} prefix={'$'} /> </Typography>
            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item xs={12} spacing={3}>
            <Grid item xs={12} sm={3}>
                <Typography  className={classes.textbox} >Loan term</Typography>                        
            </Grid>
            <Grid item xs={12} sm={3}>
            
                <TextField                             
                        id="standard-start-adornment"
                        name="loan_term"
                        value={props.parentState.loan_term}                               
                        onChange={props.valueChangeHandler}
                        InputProps={{endAdornment: (
                            <InputAdornment position="end">
                                years
                            </InputAdornment>
                            ),inputComponent: AANumberFormat}}                               
                    />

            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item xs={12} spacing={3}>
            <Grid item xs={12} sm={3}>
                <Typography  className={classes.textbox} >Repayment type</Typography>
                        
            </Grid>
            <Grid item xs={12} sm={3}>
            
                        <TextField
                                select
                                
                               
                                name='repayment_type'
                                id="demo-simple-select-outlined"
                                value={props.parentState.repayment_type}
                                onChange={props.valueChangeHandler}
                                SelectProps={{
                                    native: true,
                                }}                                
                                >
                                
                                <option value="pi">Principal and interest</option>
                                <option value="io">Interest only</option>  
                                
                            </TextField>

            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item xs={12} spacing={3}>
            <Grid item xs={12} sm={3}>
                <Typography  className={classes.textbox} >Interest rate</Typography>
                        
            </Grid>
            <Grid item xs={12} sm={3}>
            
                        <TextField
                                
                                id="standard-start-adornment"
                                name="interest_rate"
                                value={props.parentState.interest_rate}
                                
                                onChange={props.valueChangeHandler}
                                InputProps={{endAdornment: (
                                    <InputAdornment position="end">
                                    %
                                    </InputAdornment>
                                  ),inputComponent: AANumberFormat}}
                               
                            />

            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item xs={12} spacing={3}>
            <Grid item xs={12} sm={3}>
                <Typography className={classes.textbox}>LMI estimated</Typography>
            </Grid>
            <Grid container  xs={12} sm={4}>
                <Grid  xs={6} sm={6}>
                    <Radio onChange={props.valueChangeHandler} name="lmi_type" checked={props.parentState.lmi_type === "none"} value="none" color='primary'></Radio>None
                </Grid>
                <Grid  xs={6} sm={6}>
                <TextField
                        disabled={props.parentState.lmi_type === "none"}
                        className={classes.lmiTextbox}
                        id="standard-start-adornment"
                        name="lmi"
                        value={props.parentState.lmi}
                       
                        onChange={props.valueChangeHandler}
                        InputProps={{endAdornment: (
                            <InputAdornment position="end">
                            %
                            </InputAdornment>
                          ),inputComponent: AANumberFormat}}
                    />
                </Grid>
            </Grid>
            <Grid  xs={12} sm={2}>
                <Radio onChange={props.valueChangeHandler} name="lmi_type" checked={props.parentState.lmi_type === "included"} value="included" color='primary'></Radio>Included
                    
            </Grid>
            <Grid  xs={12} sm={2}>
            <Radio onChange={props.valueChangeHandler} name="lmi_type" checked={props.parentState.lmi_type === "plus_loan"} value="plus_loan" color='primary'></Radio>Plus loan
            </Grid>
        </Grid>
       
        <Grid className={classes.formcontrol} container item xs={12}>
            <Grid item xs={12} sm={3}>
                <Typography  className={classes.textbox} >LMI value</Typography>
                        
            </Grid>
            <Grid item xs={12} sm={3}>            
                <Typography className={classes.textbox}>                               
                   <CurrencyFormat value={props.calculated_values.lmi_value} displayType={'text'} thousandSeparator={true} prefix={'$'} />    
               </Typography>

            </Grid>
        </Grid>
       
        <Grid className={classes.formcontrol} container item xs={12}>
            <Grid item xs={12} sm={3}>
                <Typography  className={classes.textbox} >Available funds</Typography>
                        
            </Grid>
            <Grid item xs={12} sm={3}>
            <Typography className={classes.textbox}>     
                <CurrencyFormat value={props.calculated_values.available_fund} displayType={'text'} thousandSeparator={true} prefix={'$'} />        
            </Typography>
            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item xs={12}>
            <Grid item xs={12} sm={3}>
                <Typography  className={[classes.textbox,classes.bold]} >Monthly payments</Typography>
                        
            </Grid>
            <Grid item xs={12} sm={3}>
                    <Typography className={[classes.textbox,classes.bold]}>
                        <CurrencyFormat value={props.calculated_values.only_monthly_payment} displayType={'text'} thousandSeparator={true} prefix={'$'} />        
                    </Typography>
            </Grid>
        </Grid>
        <Grid className={[classes.formcontrol,classes.sponsorBox]} container item xs={12}>
            <Grid item xs={12} sm={12}>
            <Box >
                <Box className={[classes.sponser_box_blue,classes.marginRight]}></Box>
                <Typography className={[classes.fourteenFontSize]} >Interest Only rate, Sponsored by: sponsor name</Typography>
            </Box>
                        
            </Grid>
        </Grid>
        <Grid className={[classes.formcontrol,classes.sponsorBox]} container item xs={12}>
        <Grid item xs={12} sm={12}>
            <Box >
                  <Box className={[classes.sponser_box_red,classes.marginRight]}></Box>
                  <Typography className={[classes.fourteenFontSize]}>Principal and Interest rate, Sponsored by: sponsor name</Typography>
            </Box>
         </Grid>
        </Grid>

        <Grid className={classes.formcontrol} container item xs={12}>
            <Grid item xs={12} sm={12}>
                <Typography  className={[classes.textbox,classes.bold]} >Loan-deposit summary</Typography>
                        
            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item xs={12}>
            <Grid item xs={12} sm={5}>
                <Typography  className={[classes.textbox]} >Property purchase price less property value, variance</Typography>
                        
            </Grid>
            <Grid item xs={12} sm={5}>
                    <Typography className={[classes.textbox]}>
                        <CurrencyFormat value={props.calculated_values.variance_amount} displayType={'text'} thousandSeparator={true} prefix={'$'} />        
                    </Typography>
            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item xs={12}>
            <Grid item xs={12} sm={5}>
                <Typography  className={[classes.textbox]} >Your cash deposit</Typography>
                        
            </Grid>
            <Grid item xs={12} sm={5}>
                <Typography className={[classes.textbox]}>
                    <CurrencyFormat value={props.parentState.cash_deposit} displayType={'text'} thousandSeparator={true} prefix={'$'} />            
                </Typography>
            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item xs={12}>
            <Grid item xs={12} sm={5}>
                <Typography  className={[classes.textbox]} >As percentage of property purchase price</Typography>
                        
            </Grid>
            <Grid item xs={12} sm={5}>
                <Typography className={[classes.textbox]}>
                    {props.calculated_values.propert_price_percentage}%
                </Typography>
            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item xs={12}>
            <Grid item xs={12} sm={5}>
                <Typography  className={[classes.textbox]} >Loan-deposit amount needed to obtain the home loan</Typography>
            </Grid>
            <Grid item xs={12} sm={5}>
                <Typography className={[classes.textbox,classes.bold]}>
                    <CurrencyFormat value={props.calculated_values.needed_loan_deposit_amount} displayType={'text'} thousandSeparator={true} prefix={'$'} />            
                </Typography>
            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item xs={12}>
            <Grid item xs={12} sm={12} className={[classes.paddingTop]}>
                <Typography  className={[classes.fontColorBlue,classes.textAlignCenter,classes.fontStyleItalic]} >
                {conditional_statement_one}                      
                </Typography>
                        
            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item xs={12}>
            <Grid item xs={12} sm={12} className={[classes.paddingTop]}>
                <InputLabel  className={[classes.fontColorBlue,classes.textAlignCenter,classes.fontStyleItalic]} >
                AffordAssist offers an Australian first deposit solution, a proprietary Deferred Deposit Agreement (DDA) which may be used for all or part-of the deposit and includes a no-interest payment plan.
                </InputLabel>
                        
            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item xs={12}>
            <Grid item xs={12} sm={12} className={[classes.paddingTop]}>
                <InputLabel  className={[classes.fontColorBlue,classes.textAlignCenter,classes.fontStyleItalic]} >
                An AffordAssist DDA together with a panel of approved lenders make it possible to obtain a home loan and complete the property purchase / settlement.
                </InputLabel>
                        
            </Grid>
        </Grid>
        </Container>   
      </React.Fragment>
    );

    
  }

export default function HomePageCalcDetail(props) {
  
  return (
   
    <Grid container spacing={1}>
      <Grid container item xs={12} spacing={3}>
        <FormRowMain {...props} />
      </Grid>
      
    </Grid>
    
  );
}
