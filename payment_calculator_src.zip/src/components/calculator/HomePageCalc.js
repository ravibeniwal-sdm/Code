import React, { Component } from "react";
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { Accordion, AccordionSummary, AccordionDetails, Typography, Box, InputAdornment, OutlinedInput, Select, MenuItem, Radio,TextField } from '@material-ui/core';

import CurrencyFormat from 'react-currency-format';
import NumberFormatCustom from "./format/NumberFormatCustom";
import AANumberFormat from "./format/AANumberFormat";

import HomePageCalcDetail from "./HomePageCalcDetail";

class HomePageCalc extends Component {

    state = {
        isExpanded: false
    }
    onExpand = (event, isExpanded) => {
        console.log("onExpand--->", event, isExpanded);
        this.setState({
            isExpanded: isExpanded
        });
    };
    render() {
        const styles = {
            header: {
                borderBottom: '1px solid #008751',
                margin: '0px 16px',
                padding: '0px'
            },
            header_title: {
                fontSize: '16px',
                color: '#008751',
                fontWeight: '500'
            },
            expandIcon: {
                color: '#008751'
            },
            form_container: {
                display: 'flex',
                flexDirection: 'column',
                width: '100%'
            },
            input_box: {
                display: 'flex',
                width: '100%',
                justifyConent: 'space-between',
                padding: '8px 0px'
            },
            radio_box: {
                textAlign: 'center'
            },
            input_label: {
                width: "25%",
                display: 'flex',
                fontSize: '13px',
                alignItems: 'center'
            },
            input_label_bold: {
                width: "25%",
                display: 'flex',
                fontSize: '13px',
                fontWeight: '600',
                alignItems: 'center'
            },
            textfield: {
                width: '30%',
                height: '35px',
                fontSize: '14px'
            },
            textfield_small: {
                width: '100px',
                height: '35px',
                fontSize: '14px',
                marginLeft: '15px'
            },
            text_lable: {
                fontSize: '16px'
            },
            text_lable_bold: {
                fontSize: '16px',
                fontWeight: '600',
            },
            sponser_box: {
                backgroundColor: '#ededed',
                borderRadius: '4px',
                display: 'flex',
                flexDirection: 'column',
                padding: '10px',
                paddingBottom: '0px'
            },
            sponser_block: {
                display: 'flex',
                flexDirection: 'row',
                paddingBottom: '10px'
            },
            sponser_box_blue: {
                height: '20px',
                width: '20px',
                backgroundColor: '#0041ff'
            },
            sponser_box_red: {
                height: '20px',
                width: '20px',
                backgroundColor: '#990d00'
            },
            sponser_lable: {
                fontSize: '14px',
                padding: '0px 16px'
            },
            text_lable_price: {
                fontSize: '16px',
                fontWeight:'bold'
            },
            
            loan_summary_header: {
                
                padding: '15px',
                fontSize: '18px',
                fontWeight:'bold'
            },
            loan_summary_detail: {
                padding: '15px',
                fontSize: '14px',
                marginLeft:20,
            },
            
            sponser_tag: {
                fontSize: '14px',
                padding: '0px 16px'
            },

            message_bluecolor:{
                color:'blue',
                textAlign:'center',
                fontStyle:'italic',
                fontSize:18,
                paddingTop:20,
                paddingBottom:20
            },
            innert_message_bluecolor:{
                paddingTop:10,
            }      
        };  

        let conditional_statement_one = '';
        
        if(this.props.parentState.cash_deposit < this.props.calculated_values.needed_loan_deposit_amount)
            conditional_statement_one = "Based on the above scenario, your cash deposit is less than the loan-deposit required by a lender to obtain a home loan.";

        return (
            <Accordion onChange={this.onExpand} >
                <AccordionSummary
                    style={this.state.isExpanded ? styles.header : {}}
                    expandIcon={<ExpandMoreIcon style={styles.expandIcon} />}
                    aria-controls="panel1bh-content"
                    id="panel1bh-header"
                >
                    <Typography style={styles.header_title}>Home Loan Payments</Typography>
                </AccordionSummary>
                <AccordionDetails>
                    <HomePageCalcDetail {...this.props} />
                </AccordionDetails>
            </Accordion>
        );
    }
}

export default HomePageCalc;