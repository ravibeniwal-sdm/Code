import React from "react";
import { makeStyles, createStyles, Theme } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import {Radio, Box, Card, CardContent, Checkbox, Container, Divider, FormControl, FormHelperText, Input, InputAdornment, InputLabel, MenuItem, Select, TextField,Typography } from "@material-ui/core";
import CurrencyFormat from 'react-currency-format';

import NumberFormatCustom from "./format/NumberFormatCustom";
import AANumberFormat from "./format/AANumberFormat";
const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
        flexGrow: 1,
        padding: theme.spacing(1),
        fontFamily:'Arial',
        marginBottom: theme.spacing(3)
      },
    paper: {
      padding: theme.spacing(2),
      textAlign: "center",
      color: theme.palette.text.secondary
    },
    formcontrol: {
        padding: '8px 0px',
        fontSize :"13px",
        alignItems: 'center',
        display: 'flex',
        width: '100%',
        justifyConent: 'space-between',
    },
    textbox: {
        width: '100%',
        fontSize :"14px",
        color:"black"
    },
    textboxRadio: {
        width: '40%',
    },
    LeftLabel: {
        fontSize:"13px"
    },
    summary:{
        marginLeft: 20, 
    },
    bold:{
        fontWeight: 'bold'
       },
    
    fourteenFontSize: {
      fontSize:'14px'
    },
    tenFontSize: {
      fontSize:'10px !important'
    },
    
  })
);

  function FormRowMain(props) {
    const classes = useStyles();
    return (
      <React.Fragment>
         <Container className={classes.root} component="main" maxWidth="lg">
        <Grid className={classes.formcontrol} container item xs={12} spacing={3}>
            <Grid item xs={12} sm={5}>
                <Typography className={classes.textbox}>Purchase type</Typography>
            </Grid>
            <Grid  xs={12} sm={2}>
                 <Radio onChange={props.valueChangeHandler} name="purchase_type" checked={props.parentState.purchase_type === 'first_home_owner'} value='first_home_owner' color='primary'></Radio>First home owner
            </Grid>
            <Grid  xs={12} sm={2}>
                <Radio onChange={props.valueChangeHandler} name="purchase_type" checked={props.parentState.purchase_type === 'owner_occupied'} value='owner_occupied' color='primary'></Radio>Owner occupied
                    
            </Grid>
            <Grid  xs={12} sm={2}>
                <Radio onChange={props.valueChangeHandler} name="purchase_type" checked={props.parentState.purchase_type === 'investment'} value='investment' color='primary'></Radio>Investment
            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item>
            <Grid item xs={12} sm={5}>
                <Typography className={classes.textbox}>First-home owner grant</Typography>
                <Typography className={classes.tenFontSize}><a href="http://www.firsthome.gov.au/" target="_blank">http://www.firsthome.gov.au/</a></Typography>
                            
            </Grid>
            <Grid item xs={12} sm={5}>
                
                            <TextField
                               disabled={props.parentState.purchase_type === "investment" || props.parentState.purchase_type === "owner_occupied"}
                             
                               id="standard-start-adornment"
                               name="first_home_grant"
                               value={props.parentState.first_home_grant}
                              
                               onChange={props.valueChangeHandler}
                              InputProps={{startAdornment: (
                                <InputAdornment position="start">
                                  $
                                </InputAdornment>
                              ),inputComponent: NumberFormatCustom}}/>
            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item>
                <Grid item xs={12} sm={5}>
                      <Typography className={classes.textbox}>Other grant</Typography>
                </Grid>
                <Grid item xs={12} sm={5}>
                
                         <TextField
                              id="standard-start-adornment"
                              name="other_grant"
                              value={props.parentState.other_grant}
                             
                              onChange={props.valueChangeHandler}
                           
                            InputProps={{startAdornment: (
                                <InputAdornment position="start">
                                  $
                                </InputAdornment>
                              ),inputComponent: NumberFormatCustom}}/>
                </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item>
            <Grid item xs={12} sm={5}>
                <Typography  className={classes.textbox} >Other / incentives</Typography>
            </Grid>
            <Grid item xs={12} sm={5}>
                            <TextField
                             
                              id="standard-start-adornment"
                              name="other_incentives"
                              value={props.parentState.other_incentives}
                             
                              onChange={props.valueChangeHandler}
                            
                            InputProps={{startAdornment: (
                                <InputAdornment position="start">
                                  $
                                </InputAdornment>
                              ),inputComponent: NumberFormatCustom}}/>
            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item>
            <Grid item xs={12} sm={5}>
                <Typography  className={classes.textbox} >AffordAssist deferred deposit agreement (DDA) amount</Typography>
            </Grid>
            <Grid item xs={12} sm={5}>        
                <Typography className={classes.textbox}>                    
                    <CurrencyFormat className={classes.textbox}  value={props.calculated_values.dda_amount} displayType={'text'} thousandSeparator={true} prefix={'$'} />        
                </Typography>

            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item>
            <Grid item xs={12} sm={5}>
                <Typography  className={classes.textbox} >DDA amount as percentage of property purchase price</Typography>
                        
            </Grid>
            <Grid item xs={12} sm={5}>
                <Typography className={classes.textbox}>{props.calculated_values.dda_percentage}%</Typography>
            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item>
            <Grid item xs={12} sm={5}>
                <Typography className={classes.textbox}>Interest free term</Typography>       
            </Grid>
            <Grid item xs={12} sm={5}>
                    <TextField                               
                                id="standard-start-adornment"
                                name="interest_free_term"
                                value={props.parentState.interest_free_term}
                                
                                onChange={props.valueChangeHandler}
                                InputProps={{endAdornment: (
                                    <InputAdornment position="end">
                                     months
                                    </InputAdornment>
                                  ),inputComponent: AANumberFormat}}
                               
                            />
    
            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item>
            <Grid item xs={12} sm={5}>
                 <Typography className={classes.textbox}>Is the property off-the-plan / still being built?</Typography>
             
            </Grid>
            <Grid item xs={12} sm={5}>
            
                        <Checkbox                                
                                color='primary'
                                id="standard-start-adornment"
                                name="is_property_off_the_loan"
                                value={!props.parentState.is_property_off_the_loan}
                                onChange={props.valueChangeHandler}
                                checked={props.parentState.is_property_off_the_loan}
                            />

            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item>
            <Grid item xs={12} sm={5}>
                <Typography  className={classes.textbox} >Property due to complete in</Typography>
                        
            </Grid>
            <Grid item xs={12} sm={5}>
                         <TextField
                                disabled={!props.parentState.is_property_off_the_loan}                                
                                id="standard-start-adornment"
                                name="property_due_to_omplete"
                                value={props.parentState.property_due_to_omplete}                               
                                onChange={props.valueChangeHandler}
                                InputProps={{endAdornment: (
                                    <InputAdornment position="end">
                                     months
                                    </InputAdornment>
                                  ),inputComponent: AANumberFormat}}                               
                            />
            </Grid>
        </Grid>
        <Grid  className={classes.formcontrol} container item>
            <Grid item xs={12} sm={5}>
                <Typography  className={classes.textbox} >Minimum monthly amount payable during construction</Typography>
                        
            </Grid>
            <Grid item xs={12} sm={5}>
                    <TextField
                        
                        id="standard-start-adornment"
                        name="minimum_monthly_amount_payable"
                        value={props.parentState.minimum_monthly_amount_payable}
                        disabled={!props.parentState.is_property_off_the_loan}
                        onChange={props.valueChangeHandler}
                    InputProps={{startAdornment: (
                        <InputAdornment position="start">
                            $
                        </InputAdornment>
                    ),inputComponent: NumberFormatCustom}}/>

                   
            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item>
            <Grid item xs={12} sm={5}>
                <Typography  className={classes.textbox} >Additional funds paid into trust account and fully applied to settlement</Typography>
                        
            </Grid>
            <Grid item xs={12} sm={5}>
                    <CurrencyFormat className={classes.textbox} InputProps={{endAdornment: (
                                    <InputAdornment position="end">
                                     months
                                    </InputAdornment>
                                  )}} value={props.calculated_values.additional_funds} displayType={'text'} thousandSeparator={true} prefix={'$'} />        
                                
            </Grid>
        </Grid>
        <Divider  />
        <Grid className={classes.formcontrol} container item>
            <Grid item xs={12} sm={12}>
                <Typography  className={[classes.bold]} >Property-deposit summary</Typography>
                        
            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item>
            <Grid item xs={12} sm={5}>
                <Typography  className={[classes.textbox]} >Balance paid after settlement / completion</Typography>
                        
            </Grid>
            <Grid item xs={12} sm={5} >
                 <CurrencyFormat className={classes.textbox} value={props.calculated_values.settlement_amount} displayType={'text'} thousandSeparator={true} prefix={'$'} />        
            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item>
            <Grid item xs={12} sm={5}>
                <Typography  className={[classes.textbox]} >Payable within</Typography>
                        
            </Grid>
            <Grid item xs={12} sm={5}>
                <Typography  className={classes.textbox} >{props.calculated_values.payable_within} months</Typography>
            </Grid>
        </Grid>
        <Grid className={classes.formcontrol} container item>
            <Grid item xs={12} sm={5}>
                <Typography  className={[classes.textbox]} >Monthly interest free payments</Typography>
                        
            </Grid>
            <Grid item xs={12} sm={5}>
                <CurrencyFormat className={classes.textbox} value={props.calculated_values.only_monthly_interest_payment} displayType={'text'} thousandSeparator={true} prefix={'$'} />        
            </Grid>
        </Grid>
        </Container>
      </React.Fragment>
    );

    
  }


export default function AffordAssistDDACalDetail(props) {
  
  return (
    
      <Grid container spacing={1}>
        <Grid container item xs={12} spacing={3}>
          <FormRowMain {...props} />
        </Grid>
        
      </Grid>
    
  );
}
